import 'dart:convert';
import 'package:blue/podo/table_booking_pojo.dart';
import 'package:http/http.dart' as http;
import 'package:blue/global/constant.dart';


class TableBookingDetailsModel {
  static TableBookingOrder customer;

  static Future<void> getTableBookingDetails(String id) async {
    customer = TableBookingOrder();
    print('getTableBookingDetails called-----------$id');
    try {
      var response = await http.post(
          '${Api.businessBaseUrl}getTableBookingDetails',
          body: {"id": id});

      final jsonResponse = jsonDecode(response.body);
      print('getTableBookingDetails  jsonResponse---------------$jsonResponse');

      List<dynamic> infos = jsonResponse;

      // CustomerTB customerTb =CustomerTB(info['booking_table_id'], info['bookingDate'], info['bookingTime'], info['full_name'], info['telephone'], info['email'], info['guests'], info['status']);
      print('info-------------$infos');

      for (var info in infos) {
        print("--- info------info--------------------------${info.toString()}");
        // String tbId = info['booking_table_id'];
        // String bookingDate = info['bookingDate'];
        // String bookingTime = info['bookingTime'];
        // String fullName = info['full_name'];
        // String telephone = info['telephone'];
        // String email = info['email'];
        // String guests = info['guests'];
        // String status = info['status'];
        //
        // print('info------------------------------------------------ $tbId-$bookingDate-$fullName');


        customer.orderId =info['booking_table_id'];
        customer.orderDate = info['bookingDate'];
        customer.orderTime = info['bookingTime'];
        customer.customerName= info['full_name'];
        customer.customerContact =  info['telephone'];
        customer.customerEmail = info['email'];
        customer.numberOfGuest = info['guests'];
        customer.status = info['status'];

        print(
            'customer.orderId------------------------------------------------ ${customer.orderId}');
      }

      // print('booking_table_id----$tbId-----$bookingDate----$fullName-$email--$status--');
      //
      //

    } catch (e, s) {
      print(e.toString());

      print(s.toString());
    }
  }
}
