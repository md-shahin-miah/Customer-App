class TableBookingOrder{
  String orderId;
  String orderDate;
  String orderTime;
  String customerName;
  String customerContact;
  String customerEmail;
  String numberOfGuest;
  String status;

  TableBookingOrder();
}


