class TableBooking {
  int orderId;
  String orderDate;
  String orderTime;
  String customerName;
  String customerContact;
  String customerEmail;
  int numberOfGuest;
  String status;

  TableBooking(this.orderId, this.orderDate,this.orderTime, this.customerName, this.customerContact,
      this.customerEmail, this.numberOfGuest, this.status);
}
