import 'dart:io';

import 'package:blue/global/constant.dart';
import 'package:blue/global_provider.dart';
import 'package:blue/main.dart';
import 'package:blue/printer/front_receipt.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';




class PrinterHome extends StatefulWidget {
  @override
  _PrinterHomeState createState() => new _PrinterHomeState();
}

class _PrinterHomeState extends State<PrinterHome> {

  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  List<BluetoothDevice> _devices = [];
  BluetoothDevice _device;
  bool _connected = false;
  String pathImage;
  FrontReceipt frontReceipt;

  @override
  void initState() {
    super.initState();
    initPlatformState();
    // initSavetoPath();
    frontReceipt= FrontReceipt();
  }

  // initSavetoPath()async{
  //   //read and write
  //   //image max 300px X 300px
  //   final filename = 'yourlogo.png';
  //   var bytes = await rootBundle.load("assets/images/yourlogo.png");
  //   String dir = (await getApplicationDocumentsDirectory()).path;
  //   writeToFile(bytes,'$dir/$filename');
  //   setState(() {
  //     pathImage='$dir/$filename';
  //   });
  // }


  Future<void> initPlatformState() async {
    bool isConnected=await bluetooth.isConnected;
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } on PlatformException {
      // TODO - Error
    }

    bluetooth.onStateChanged().listen((state) {
      switch (state) {
        case BlueThermalPrinter.CONNECTED:
          setState(() {
            _connected = true;
          });
          break;
        case BlueThermalPrinter.DISCONNECTED:
          setState(() {
            _connected = false;
          });
          break;
        default:
          print(state);
          break;
      }
    });

    if (!mounted) return;
    setState(() {
      _devices = devices;
    });

    if(isConnected) {
      setState(() {
        _connected=true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: AppBar(

          title: Text('Paired Devices'),
          centerTitle: true,
        ),

        body:RefreshIndicator(
          onRefresh: initPlatformState,
          backgroundColor: Colors.deepOrange,
          color: Colors.white,
          displacement: 150,
          strokeWidth: 4,
          child: Column(
            children: [

             Container(
                child: ListView.builder(
                    itemCount: _devices.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, int index) {
                      return  InkWell(

                          onTap: ()async{
                            _connect(_devices[index]);
                            Static.DEVICE_NAME=_devices[index].name;
                            SharedPreferences prefs = await SharedPreferences.getInstance();
                            await prefs.setString('device_name', (_devices[index]).name);
                            await prefs.setString('device_address', (_devices[index]).address);
                            await prefs.setInt('device_type', (_devices[index]).type).then((value) => intent());
                            Provider.of<GlobalProvider>(context, listen: false).setBluetoothDevice(_devices[index]);

                            print('_devices onTap ---------------------------------------${_devices[index]}');

                        },
                        child: ListTile(
                          // leading: FlutterLogo(),
                          title: Text(_devices[index].name),
                          subtitle: Text(_devices[index].address),

                        ),
                      );
                    }
                ),
              ),

            ],
          ),
        )

      );
  }


  List<DropdownMenuItem<BluetoothDevice>> _getDeviceItems() {
    List<DropdownMenuItem<BluetoothDevice>> items = [];
    if (_devices.isEmpty) {
      items.add(DropdownMenuItem(
        child: Text('NONE'),
      ));
    } else {
      _devices.forEach((device) {
        items.add(DropdownMenuItem(
          child: Text(device.name),
          value: device,
        ));
      });
    }
    return items;
  }


  void _connect(BluetoothDevice devic) {
    if (devic == null) {
      show('No device selected.');
    } else {
      bluetooth.isConnected.then((isConnected) {
        if (!isConnected) {
          bluetooth.connect(devic).catchError((error) {
             Provider.of<GlobalProvider>(context, listen: false).setPrinterConnectFalse();

            setState(() => _connected = false);
          });

          setState(() => _connected = true);
          Provider.of<GlobalProvider>(context, listen: false).setPrinterConnectTrue();
        }
      });
    }
  }


  void _disconnect() {
    bluetooth.disconnect();
    setState(() => _connected = false);
  }

//write to app path
  Future<void> writeToFile(ByteData data, String path) {
    final buffer = data.buffer;
    return new File(path).writeAsBytes(
        buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
  }

  Future show(
      String message, {
        Duration duration: const Duration(seconds: 3),
      }) async {
    await new Future.delayed(new Duration(milliseconds: 100));
    Scaffold.of(context).showSnackBar(
      new SnackBar(
        content: new Text(
          message,
          style: new TextStyle(
            color: Colors.white,
          ),
        ),
        duration: duration,
      ),
    );
  }

  intent() {
    if(_connected){
      Provider.of<GlobalProvider>(context, listen: false)
          .setPrinterConnectTrue();
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => MyApp()));
    }
    // else{
    //   Scaffold.of(context).showSnackBar(
    //     new SnackBar(
    //       content: new Text(
    //         'Device not connected',
    //         style: new TextStyle(
    //           color: Colors.white,
    //         ),
    //       ),
    //       duration:const Duration(seconds: 1),
    //     ),
    //   );
    //
    //   Navigator.pushReplacement(
    //       context, MaterialPageRoute(builder: (_) => MyApp()));
    // }
  }






}

Future show(
    String message, {
      Duration duration: const Duration(seconds: 3),
    }) async {
  await new Future.delayed(new Duration(milliseconds: 100));

}