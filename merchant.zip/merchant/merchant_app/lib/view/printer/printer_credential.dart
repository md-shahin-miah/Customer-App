import '../../global_provider.dart';
import 'file:///C:/Users/U%20S%20E%20R/AndroidStudioProjects/merchant_app/merchant/merchant_app/lib/view/printer/printer_home.dart';
import 'package:blue/global/constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PrinterCredential extends StatefulWidget {
  static final String path = "lib/src/pages/settings/settings3.dart";

  @override
  _PrinterCredentialState createState() => _PrinterCredentialState();
}

class _PrinterCredentialState extends State<PrinterCredential> {
  final TextStyle headerStyle = TextStyle(
    color: Colors.grey,
    fontWeight: FontWeight.normal,
    fontSize: 18.0,
  );

  bool isLoading = false;
  bool enablePendingOrderSound = true;
  bool hideRestaurantAddressOnReceipt = false;
  bool displayOrderIdTable = true;
  bool autoPrintTableBookingReceipt = false;
  bool autoPrintOrder = true;
  bool showOnlyCurrentDaysOrder = false;
  bool kitchenReceiptDefault = true;
  bool kitchenReceiptSameAsFront = false;
  bool displayOrderIdInReceipt = true;
  bool displayAwaitingNotPaidPayment = false;
  bool enableAwaitingNotPaidPaymentSound = false;

  // ignore: non_constant_identifier_names
  String Unconfirmed_payment_button_Value = 'Awaiting';

  // ignore: non_constant_identifier_names
  String Number_of_front_receipt_Value = 'One';

  // ignore: non_constant_identifier_names
  String Number_of_kitchen_receipt_Value = 'One';

  // ignore: non_constant_identifier_names
  String Pending_order_sound_length_value = 'Short';
  var textStyle = 'Unconfirmed payment button';

  var isFirstTIme=0;




  Future saveToPref() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('enablePendingOrderSound', enablePendingOrderSound);
    await prefs.setBool(
        'hideRestaurantAddressOnReceipt', hideRestaurantAddressOnReceipt);
    await prefs.setBool('displayOrderIdTable', displayOrderIdTable);
    await prefs.setBool(
        'autoPrintTableBookingReceipt', autoPrintTableBookingReceipt);
    await prefs.setBool('autoPrintOrder', autoPrintOrder);
    await prefs.setBool('showOnlyCurrentDaysOrder', showOnlyCurrentDaysOrder);
    await prefs.setBool('kitchenReceiptDefault', kitchenReceiptDefault);
    await prefs.setBool('kitchenReceiptSameAsFront', kitchenReceiptSameAsFront);
    await prefs.setBool('displayOrderIdInReceipt', displayOrderIdInReceipt);
    await prefs.setBool(
        'displayAwaitingNotPaidPayment', displayAwaitingNotPaidPayment);
    await prefs.setBool(
        'enableAwaitingNotPaidPaymentSound', enableAwaitingNotPaidPaymentSound);

    await prefs.setString(
        'Unconfirmed_payment_button_Value', Unconfirmed_payment_button_Value);
    await prefs.setString(
        'Number_of_front_receipt_Value', Number_of_front_receipt_Value);
    await prefs.setString(
        'Number_of_kitchen_receipt_Value', Number_of_kitchen_receipt_Value);
    await prefs.setString(
        'Pending_order_sound_length_value', Pending_order_sound_length_value);
    await prefs.setInt(
        'isfirst', 2);
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    SharedPreferences.getInstance().then((prefs) {
      Static.enablePendingOrderSound =
          prefs.getBool('enablePendingOrderSound') ?? false;
      Static.hideRestaurantAddressOnReceipt =
          prefs.getBool('hideRestaurantAddressOnReceipt') ?? false;
      Static.displayOrderIdTable =
          prefs.getBool('displayOrderIdTable') ?? false;
      Static.autoPrintTableBookingReceipt =
          prefs.getBool('autoPrintTableBookingReceipt') ?? false;
      Static.autoPrintOrder = prefs.getBool('autoPrintOrder') ?? false;
      Static.showOnlyCurrentDaysOrder =
          prefs.getBool('showOnlyCurrentDaysOrder') ?? false;
      Static.kitchenReceiptDefault =
          prefs.getBool('kitchenReceiptDefault') ?? false;
      Static.kitchenReceiptSameAsFront =
          prefs.getBool('kitchenReceiptSameAsFront') ?? false;
      Static.displayOrderIdInReceipt =
          prefs.getBool('displayOrderIdInReceipt') ?? false;
      Static.displayAwaitingNotPaidPayment =
          prefs.getBool('displayAwaitingNotPaidPayment') ?? false;
      Static.enableAwaitingNotPaidPaymentSound =
          prefs.getBool('enableAwaitingNotPaidPaymentSound') ?? false;

      Static.Unconfirmed_payment_button_Value =
          prefs.getString('Unconfirmed_payment_button_Value') ?? null;
      Static.Number_of_front_receipt_Value =
          prefs.getString('Number_of_front_receipt_Value') ?? null;
      Static.Number_of_kitchen_receipt_Value =
          prefs.getString('Number_of_kitchen_receipt_Value') ?? null;
      Static.Pending_order_sound_length_value =
          prefs.getString('Pending_order_sound_length_value') ?? null;
      isFirstTIme=prefs.getInt('isfirst')??0;



      // setState(() {
      //   enablePendingOrderSound = Static.enablePendingOrderSound;
      //   hideRestaurantAddressOnReceipt = Static.hideRestaurantAddressOnReceipt;
      //   displayOrderIdTable = Static.displayOrderIdTable;
      //   autoPrintTableBookingReceipt = Static.autoPrintTableBookingReceipt;
      //   autoPrintOrder = Static.autoPrintOrder;
      //   showOnlyCurrentDaysOrder = Static.showOnlyCurrentDaysOrder;
      //   kitchenReceiptDefault = Static.kitchenReceiptDefault;
      //   kitchenReceiptSameAsFront = Static.kitchenReceiptSameAsFront;
      //   displayOrderIdInReceipt = Static.displayOrderIdInReceipt;
      //   displayAwaitingNotPaidPayment = Static.displayAwaitingNotPaidPayment;
      //   enableAwaitingNotPaidPaymentSound =
      //       Static.enableAwaitingNotPaidPaymentSound;
      //
      //   // ignore: non_constant_identifier_names
      //   Unconfirmed_payment_button_Value =
      //       Static.Unconfirmed_payment_button_Value;
      //
      //   // ignore: non_constant_identifier_names
      //   Number_of_front_receipt_Value = Static.Number_of_front_receipt_Value;
      //
      //   // ignore: non_constant_identifier_names
      //   Number_of_kitchen_receipt_Value =
      //       Static.Number_of_kitchen_receipt_Value;
      //
      //   // ignore: non_constant_identifier_names
      //   Pending_order_sound_length_value =
      //       Static.Pending_order_sound_length_value;
      // });
    });
  }

  @override
  Widget build(BuildContext context) {
    final providerGlobal = Provider.of<GlobalProvider>(context);
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: Text(
          'Settings',
        ),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
              isFirstTIme==1?Container():
              Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          providerGlobal.getPrinterConnectionStatus
                              ? Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Icon(
                                        Icons.print,
                                        color: Colors.green,
                                        size: 32,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Printer is connected',
                                        style: TextStyle(color: Colors.green),
                                      ),
                                    )
                                  ],
                                )
                              : Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Icon(
                                        Icons.print_disabled,
                                        color: Colors.red,
                                        size: 32,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Printer is not connected',
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    )
                                  ],
                                ),
                        ],
                      ),
                    ),
                  ),
                ),
                Text(
                  "SETTINGS",
                  style: headerStyle,
                ),
                const SizedBox(height: 5.0),
                Card(
                  elevation: 0.5,
                  margin: const EdgeInsets.symmetric(
                    vertical: 4.0,
                    horizontal: 0,
                  ),
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: Container(
                                child: Text('Unconfirmed payment button'),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 0),
                                  child: DropdownButton<String>(
                                    value: Unconfirmed_payment_button_Value,
                                    // icon: const Icon(Icons.arrow_downward),
                                    iconSize: 24,
                                    elevation: 16,
                                    style: const TextStyle(
                                        color: Colors.deepPurple),
                                    underline: Container(
                                      height: 0,
                                      color: Colors.deepPurpleAccent,
                                    ),
                                    onChanged: (String newValue) {
                                      setState(() {
                                        Unconfirmed_payment_button_Value =
                                            newValue;
                                      });
                                    },
                                    items: <String>[
                                      'Not paid',
                                      'Awaiting',
                                    ].map<DropdownMenuItem<String>>(
                                        (String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: Container(
                                child: Text('Number of front receipt'),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 0),
                                  child: DropdownButton<String>(
                                    value: Number_of_front_receipt_Value,
                                    // icon: const Icon(Icons.arrow_downward),
                                    iconSize: 24,
                                    elevation: 16,
                                    style: const TextStyle(
                                        color: Colors.deepPurple),
                                    underline: Container(
                                      height: 0,
                                      color: Colors.deepPurpleAccent,
                                    ),
                                    onChanged: (String newValue) {
                                      setState(() {
                                        Number_of_front_receipt_Value =
                                            newValue;
                                      });
                                    },
                                    items: <String>[
                                      'One',
                                      'Two',
                                      'Three',
                                      'Four',
                                      'Five'
                                    ].map<DropdownMenuItem<String>>(
                                        (String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: Container(
                                child: Text('Number of kitchen receipt'),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 0),
                                  child: DropdownButton<String>(
                                    value: Number_of_kitchen_receipt_Value,
                                    // icon: const Icon(Icons.arrow_downward),
                                    iconSize: 24,
                                    elevation: 16,
                                    style: const TextStyle(
                                        color: Colors.deepPurple),
                                    underline: Container(
                                      height: 0,
                                      color: Colors.deepPurpleAccent,
                                    ),
                                    onChanged: (String newValue) {
                                      setState(() {
                                        Number_of_kitchen_receipt_Value =
                                            newValue;
                                      });
                                    },
                                    items: <String>[
                                      'One',
                                      'Two',
                                      'Three',
                                      'Four',
                                      'Five'
                                    ].map<DropdownMenuItem<String>>(
                                        (String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: Container(
                                child: Text('Pending order sound length'),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 0),
                                  child: DropdownButton<String>(
                                    value: Pending_order_sound_length_value,
                                    // icon: const Icon(Icons.arrow_downward),
                                    iconSize: 24,
                                    elevation: 16,
                                    style: const TextStyle(
                                        color: Colors.deepPurple),
                                    underline: Container(
                                      height: 0,
                                      color: Colors.deepPurpleAccent,
                                    ),
                                    onChanged: (String newValue) {
                                      setState(() {
                                        Pending_order_sound_length_value =
                                            newValue;
                                      });
                                    },
                                    items: <String>[
                                      'Short',
                                      'Medium',
                                      'Long',
                                    ].map<DropdownMenuItem<String>>(
                                        (String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                    ],
                  ),
                ),
                const SizedBox(height: 10.0),
                Text(
                  "MORE SETTINGS",
                  style: headerStyle,
                ),
                SizedBox(height: 5.0),
                Card(
                  margin: const EdgeInsets.symmetric(
                    vertical: 8.0,
                    horizontal: 0,
                  ),
                  child: Column(
                    children: <Widget>[
                      // Padding(
                      //   padding: const EdgeInsets.all(12.0),
                      //   child: Row(
                      //     children: [
                      //       Expanded(
                      //           flex: 7,
                      //           child: Container(
                      //             child: Text('Display Table Booking'),
                      //           )),
                      //       Expanded(
                      //         flex: 2,
                      //         child: Container(
                      //           height: 28,
                      //           child: FlutterSwitch(
                      //             showOnOff: true,
                      //             activeColor: Colors.green,
                      //             activeTextColor: Colors.black,
                      //             inactiveTextColor: Colors.blue[50],
                      //             value: displayTableBooking,
                      //             onToggle: (val) {
                      //               setState(() {
                      //                 displayTableBooking = val;
                      //               });
                      //             },
                      //           ),
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      // _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Enable pending order sound'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: enablePendingOrderSound,
                                  onToggle: (val) {
                                    setState(() {
                                      enablePendingOrderSound = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text(
                                      'Hide restaurant address on receipt'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: hideRestaurantAddressOnReceipt,
                                  onToggle: (val) {
                                    setState(() {
                                      hideRestaurantAddressOnReceipt = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Display order id table'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: displayOrderIdTable,
                                  onToggle: (val) {
                                    setState(() {
                                      displayOrderIdTable = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child:
                                      Text('Auto print table booking receipt'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: autoPrintTableBookingReceipt,
                                  onToggle: (val) {
                                    setState(() {
                                      autoPrintTableBookingReceipt = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Auto print order '),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: autoPrintOrder,
                                  onToggle: (val) {
                                    setState(() {
                                      autoPrintOrder = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Show only current days order'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: showOnlyCurrentDaysOrder,
                                  onToggle: (val) {
                                    setState(() {
                                      showOnlyCurrentDaysOrder = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Kitchen receipt(Default)'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: kitchenReceiptDefault,
                                  onToggle: (val) {
                                    setState(() {
                                      kitchenReceiptDefault = val;
                                      kitchenReceiptSameAsFront = false;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child:
                                      Text('Kitchen receipt(same as  front)'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: kitchenReceiptSameAsFront,
                                  onToggle: (val) {
                                    setState(() {
                                      kitchenReceiptSameAsFront = val;
                                      kitchenReceiptDefault = false;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text('Display order id(in receipt)'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: displayOrderIdInReceipt,
                                  onToggle: (val) {
                                    setState(() {
                                      displayOrderIdInReceipt = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child:
                                      Text('Display awaiting/not paid payment'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: displayAwaitingNotPaidPayment,
                                  onToggle: (val) {
                                    setState(() {
                                      displayAwaitingNotPaidPayment = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildDivider(),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 7,
                                child: Container(
                                  child: Text(
                                      'Enable awaiting /not paid  payment sound'),
                                )),
                            Expanded(
                              flex: 2,
                              child: Container(
                                height: 28,
                                child: FlutterSwitch(
                                  activeColor: Colors.green,
                                  showOnOff: true,
                                  activeTextColor: Colors.white,
                                  inactiveTextColor: Colors.blue[50],
                                  value: enableAwaitingNotPaidPaymentSound,
                                  onToggle: (val) {
                                    setState(() {
                                      enableAwaitingNotPaidPaymentSound = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Container(
                    height: 60,
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        RaisedButton(
                            color: Colors.deepOrange,
                            onPressed: () {
                              isLoading = true;
                              saveToPref().then((value) => goIntent());
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Submit',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 20),
                              ),
                            )),
                      ],
                    ),
                  ),
                ),

                // Card(
                //   margin: const EdgeInsets.symmetric(
                //     vertical: 8.0,
                //     horizontal: 0,
                //   ),
                //   child: ListTile(
                //     leading: Icon(Icons.exit_to_app),
                //     title: Text("Logout"),
                //     onTap: () {},
                //   ),
                // ),
                const SizedBox(height: 30.0),
              ],
            ),
          ),
          isLoading
              ? Center(
                  child: Container(
                      color: Colors.transparent,
                      child: CircularProgressIndicator()))
              : Container(),
        ],
        // child:
      ),
    );
  }

  Container _buildDivider() {
    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 8.0,
      ),
      width: double.infinity,
      height: 1.0,
      color: Colors.grey.shade300,
    );
  }

  goIntent() {
    isLoading = false;
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => PrinterHome()));
  }


}
