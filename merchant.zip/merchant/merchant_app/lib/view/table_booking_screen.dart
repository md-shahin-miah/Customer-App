import 'dart:ui';

import 'package:blue/global/constant.dart';
import 'package:blue/model/home_model.dart';
import 'package:blue/model/tablebookiing_details_model.dart';
import 'package:blue/model/tablebooking_model.dart';
import '../global_provider.dart';
import 'file:///C:/Users/U%20S%20E%20R/AndroidStudioProjects/merchant_app/merchant/merchant_app/lib/podo/table_booking.dart';
import 'package:blue/schedule/widgets/constants.dart';
import 'file:///C:/Users/U%20S%20E%20R/AndroidStudioProjects/merchant_app/merchant/merchant_app/lib/printer/table_booking_receipt.dart';
import 'package:flutter/material.dart';
import 'package:blue/model/order_model.dart';
import 'package:blue/view/order_details.dart';
import 'package:blue/view/loader.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:group_radio_button/group_radio_button.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class TableBookingScreen extends StatefulWidget {
  @override
  _TableBookingScreenState createState() => _TableBookingScreenState();
}

class _TableBookingScreenState extends State<TableBookingScreen> {
  TableBookingReceipt tableBookingReceipt;
  int initialTabIndex = 0;
  bool isLoading = true;
  bool isLoadingForTB = false;
  List<String> options = ["Today", "This week", "This month"];
  String optionDropdownValue = "Today";

  DateTime selectedDate = DateTime.now();
  List<String> _dateList = [];
  final bool isStartButtonClicked = false;
  String startDate = '';
  String startDateSend = '';
  String endDate = '';
  String endDateSend = '';

  DateTime startDateFormat = DateTime.now();

  DateTime today = DateTime.now();

  @override
  void initState() {
    tableBookingReceipt = TableBookingReceipt();

    TableBookingModel.getAllTableBooking(1).then((value) {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    });

    print('order api called');

    print('pending orders');
    print(TableBookingModel.pendingOrders.length);

    super.initState();
  }

  void _selectDate(BuildContext context, int from) async {
    if (from == Constant.END_DATE) {
      today = DateTime.now();
    }

    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: from == Constant.START_DATE ? today : today,
      // startDateFormat == null
      //     ? today
      //     : startDateFormat.add(new Duration(days: 1)),

      firstDate: from == Constant.START_DATE
          ? startDateFormat.add(new Duration(days: -1000))
          : today.add(new Duration(days: -1000)),
      // ? today
      // : startDateFormat.add(new Duration(days: 1)),

      lastDate: from == Constant.START_DATE ? today : today,

      // today.add(new Duration(days: 1000)),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        // selectedDate = picked;
        _dateList.add((DateFormat.yMMMMEEEEd().format(picked)).toString());
        if (from == Constant.START_DATE) {
          setState(() {
            startDate = (DateFormat.yMMMMEEEEd().format(picked)).toString();
            startDateSend =
                (DateFormat('yyyy-MM-dd 00.00.00').format(picked)).toString();
            startDateFormat = picked;
          });
        } else if (from == Constant.END_DATE) {
          setState(() {
            endDate = (DateFormat.yMMMMEEEEd().format(picked)).toString();
            endDateSend =
                (DateFormat('yyyy-MM-dd 23.59.59').format(picked)).toString();
          });
        }
      });
  }

  List<String> _status = [
    "Today",
    "Last 7 days",
    "Last 30 days",
    "This year",
    "Range"
  ];

  void _filterOrderByDate() {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(8))),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Sort orders'),
                IconButton(
                  color: Colors.red,
                  icon: Icon(Icons.close),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                )
              ],
            ),
            content: Container(
              decoration: BoxDecoration(
                  border: Border.all(
                color: Colors.grey[300],
                width: 1.0,
              )),
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: optionDropdownValue,
                  icon: Icon(Icons.arrow_drop_down),
                  iconSize: 24,
                  elevation: 16,
                  style: TextStyle(color: Colors.black, fontSize: 18),
                  underline: SizedBox(),
                  onChanged: (String data) async {
                    optionDropdownValue = data;
                    int val = 1;
                    if (optionDropdownValue == "This week") {
                      val = 2;
                    } else if (optionDropdownValue == "This month") {
                      val = 3;
                    }

                    setState(() {
                      isLoading = false;
                      Navigator.pop(context);
                    });

                    final overlay = LoadingOverlay.of(context);
                    await overlay
                        .during(TableBookingModel.getAllTableBooking(val));
                    TableBookingModel.getAllTableBooking(val).then((value) {
                      setState(() {
                        isLoading = false;
                      });
                    });
                  },
                  items: options.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
            )));
  }

  String _verticalGroupValue = "Today";
  bool isVisibleRange = false;
  bool isVisibleFrom = false;
  bool isVisibleTo = false;

  Future _dataSearch(int val) async {
    // final overlay = LoadingOverlay.of(context);
    // await overlay.during(TableBookingModel.getAllOrders(val));
    TableBookingModel.getAllTableBooking(val).then((value) {
      print(
          'pendingOrders-----------------------------${TableBookingModel.pendingOrders.length}');
      setState(() {
        isLoading = false;
      });
    });
  }

  Future _dataSearchByRange() async {
    // final overlay = LoadingOverlay.of(context);
    // await overlay.during(TableBookingModel.getAllOrders(val));
    if (startDate.isNotEmpty && endDate.isNotEmpty) {
      TableBookingModel.getAllTableBookingByRange(startDateSend, endDateSend)
          .then((value) {
        print(
            'pendingOrders-----------------------------${TableBookingModel.pendingOrders.length}');
        setState(() {
          isLoading = false;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if(Provider.of<GlobalProvider>(context, listen: true).getIsOrderArrived()){
      _refreshData();
    }
    print('build called--tb--${ Provider.of<GlobalProvider>(context, listen: true).getIsOrderArrived()}');
    return Scaffold(
        appBar: AppBar(
          title: Text('Table Booking details'),
          actions: [
            // IconButton(
            //     icon: Icon(Icons.sort),
            //     onPressed: () {
            //       _filterOrderByDate();
            //     }),
          ],
        ),
        endDrawer: Drawer(
          child: ListView(shrinkWrap: true, children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Search table booking',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            _buildDivider(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: RadioGroup<String>.builder(
                direction: Axis.vertical,
                groupValue: _verticalGroupValue,
                onChanged: (value) async {
                  setState(() {
                    _verticalGroupValue = value;
                  });

                  if (value == "Range") {
                    setState(() {
                      isVisibleRange = true;
                    });
                  } else {
                    setState(() {
                      isVisibleRange = false;
                    });
                  }
                },
                items: _status,
                itemBuilder: (item) => RadioButtonBuilder(
                  item,
                ),
              ),
            ),
            isVisibleRange ? _buildDivider() : Container(),
            // Padding(
            //   padding: const EdgeInsets.only(top: 10),
            //   child: RaisedButton(
            //       textColor: Colors.white,
            //       color: Colors.deepOrange,
            //       child: Text('Search with range'),
            //       onPressed: () {
            //
            //       }),
            // ),
            isVisibleRange
                ? Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RaisedButton(
                                textColor: Colors.white,
                                color: Colors.green,
                                child: Text('From'),
                                onPressed: () {
                                  _selectDate(context, Constant.START_DATE);
                                  setState(() {
                                    isVisibleFrom = true;
                                  });
                                }),
                            SizedBox(
                              height: 10,
                              width: 10,
                            ),
                            RaisedButton(
                                textColor: Colors.white,
                                color: Colors.deepOrange,
                                child: Text('To'),
                                onPressed: () {
                                  _selectDate(context, Constant.END_DATE);
                                  setState(() {
                                    isVisibleTo = true;
                                  });
                                })
                          ],
                        ),
                        isVisibleFrom
                            ? Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'From',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text('$startDate $startDateSend',
                                        style: TextStyle(color: Colors.grey)),
                                  ],
                                ),
                              )
                            : Container(),
                        isVisibleTo
                            ? Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'To',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text('$endDate $endDateSend',
                                        style: TextStyle(color: Colors.grey)),
                                  ],
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  )
                : Container(),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: RaisedButton(color: Colors.green,
                onPressed: () {
                  setState(() {
                    isLoading = true;
                  });
                  if (_verticalGroupValue == "Today") {
                    print('---------------------------------Today');
                    Navigator.pop(context);
                    _dataSearch(1).then((value) => () {
                          setState(() {
                            isLoading = false;
                          });
                        });
                  } else if (_verticalGroupValue == "Last 7 days") {
                    print(
                        '-----------------------------------------------Last 7 days');
                    Navigator.pop(context);
                    _dataSearch(2).then((value) => () {
                          setState(() {
                            isLoading = false;
                          });
                        });
                  } else if (_verticalGroupValue == "Last 30 days") {
                    print(
                        '------------------------------------------------------Last 30 days');
                    Navigator.pop(context);
                    _dataSearch(3).then((value) => () {
                          setState(() {
                            isLoading = false;
                          });
                        });
                  } else if (_verticalGroupValue == "This year") {
                    print(
                        '------------------------------------------------------This year');
                    Navigator.pop(context);
                    _dataSearch(4).then((value) => () {
                          setState(() {
                            isLoading = false;
                          });
                        });
                  } else if (_verticalGroupValue == "Range") {
                    print(
                        '------------------------------------------------------Range');
                    Navigator.pop(context);
                    _dataSearchByRange().then((value) => () {
                          setState(() {
                            isLoading = false;
                          });
                        });
                  }
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.search,color: Colors.white,),
                    Text('Search',style: TextStyle(color: Colors.white),)
                  ],
                ),
              ),
            )
          ]),
        ),
        body: HomeModel.isTableBookingOn
            ? RefreshIndicator(
                onRefresh: _refreshData,
                backgroundColor: Colors.deepOrange,
                color: Colors.white,
                displacement: 150,
                strokeWidth: 4,
                child: isLoadingForTB
                    ? Container(
                        child: Center(
                            child: CircularProgressIndicator(
                        backgroundColor: Colors.transparent,
                      )))
                    : ListView(
                        children: [
                          DefaultTabController(
                              length: 3, // length of tabs
                              initialIndex: initialTabIndex,
                              child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: <Widget>[
                                    Container(
                                      child: TabBar(
                                        labelColor: Colors.deepOrange,
                                        unselectedLabelColor: Colors.black,
                                        // isScrollable:
                                        //     : true,
                                        tabs: [
                                          Tab(text: 'Pending'),
                                          Tab(text: 'Accepted'),
                                          Tab(text: 'Cancelled'),
                                          // Static.displayAwaitingNotPaidPayment
                                          // ? Tab(text: '${Static.Unconfirmed_payment_button_Value}')
                                          // : Container(height: 0,width: 0,),
                                        ],
                                      ),
                                    ),
                                    Container(
                                        height:
                                            MediaQuery.of(context).size.height -
                                                (210), //height of TabBarView
                                        decoration: BoxDecoration(
                                            border: Border(
                                                top: BorderSide(
                                                    color: Colors.grey,
                                                    width: 0.5))),
                                        child: TabBarView(children: <Widget>[
                                          TableBookingModel
                                                      .pendingOrders.length ==
                                                  0
                                              ? isLoading
                                                  ? Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                          CircularProgressIndicator()
                                                        ])
                                                  : Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Icon(
                                                          Icons.calendar_today_outlined,
                                                          size: 120,
                                                          color:
                                                              Colors.grey[300],
                                                        ),
                                                        //   Container(
                                                        //     height: MediaQuery.of(context).size.width/2,
                                                        //     width: MediaQuery.of(context).size.height/3,
                                                        //     child: Padding(
                                                        //       padding: const EdgeInsets.all(8.0),
                                                        //       child: SvgPicture.asset('assets/table.svg'),
                                                        //     ),
                                                        //   ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          'No table booking found!',
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color:
                                                                  Colors.grey),
                                                        ),
                                                      ],
                                                    )
                                              : ListView.builder(
                                                  itemCount: TableBookingModel
                                                      .pendingOrders.length,
                                                  itemBuilder:
                                                      (BuildContext ctxt,
                                                          int index) {
                                                    if (index >
                                                        TableBookingModel
                                                            .pendingOrders
                                                            .length) {
                                                      return SizedBox();
                                                    }
                                                    return Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 5.0,
                                                              right: 5),
                                                      child: Card(
                                                        child: InkWell(
                                                          onTap: () {
                                                            if (!Static
                                                                .autoPrintTableBookingReceipt) {
                                                              _showMyDialog(
                                                                  (TableBookingModel
                                                                          .pendingOrders[
                                                                      index]));
                                                            }
                                                          },
                                                          child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        right:
                                                                            8.0),
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Icon(
                                                                        Icons
                                                                            .table_chart_outlined,
                                                                        size:
                                                                            30,
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      flex: 3,
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Static.displayOrderIdTable
                                                                              ? Text(
                                                                                  '#${TableBookingModel.pendingOrders[index].orderId}',
                                                                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                                                                )
                                                                              : Container(),
                                                                          Text(
                                                                            '${TableBookingModel.pendingOrders[index].customerName}',
                                                                            style: TextStyle(
                                                                                fontWeight: FontWeight.normal,
                                                                                color: Colors.black,
                                                                                fontSize: 14),
                                                                          ),
                                                                          Text(
                                                                            '${TableBookingModel.pendingOrders[index].customerEmail}',
                                                                            style: TextStyle(
                                                                                fontWeight: FontWeight.normal,
                                                                                color: Colors.black,
                                                                                fontSize: 12),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      flex: 2,
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.end,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.end,
                                                                        children: [
                                                                          FittedBox(
                                                                            child:
                                                                                Text(
                                                                              'Date: ${TableBookingModel.pendingOrders[index].orderDate}',
                                                                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding:
                                                                                const EdgeInsets.only(bottom: 4),
                                                                            child:
                                                                                Card(
                                                                              color: Colors.black,
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(4.0),
                                                                                child: Text(
                                                                                  'Time-${TableBookingModel.pendingOrders[index].orderTime}',
                                                                                  style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding:
                                                                                const EdgeInsets.only(bottom: 4),
                                                                            child:
                                                                                Card(
                                                                              color: Colors.black,
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(4.0),
                                                                                child: FittedBox(
                                                                                  child: Text(
                                                                                    'Number of guests-${TableBookingModel.pendingOrders[index].numberOfGuest}',
                                                                                    style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }),
                                          TableBookingModel
                                                      .acceptedOrders.length ==
                                                  0
                                              ? isLoading
                                                  ? Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                          CircularProgressIndicator()
                                                        ])
                                                  : Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        // Container(
                                                        //   height: MediaQuery.of(context).size.width/2,
                                                        //   width: MediaQuery.of(context).size.height/3,
                                                        //   child: Padding(
                                                        //     padding: const EdgeInsets.all(8.0),
                                                        //     child: SvgPicture.asset('assets/table.svg'),
                                                        //   ),
                                                        // ),
                                                        Icon(
                                                          Icons.calendar_today_outlined,
                                                          size: 120,
                                                          color:
                                                              Colors.grey[300],
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          'No table booking found!',
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color:
                                                                  Colors.grey),
                                                        ),
                                                      ],
                                                    )
                                              : ListView.builder(
                                                  itemCount: TableBookingModel
                                                      .acceptedOrders.length,
                                                  itemBuilder:
                                                      (BuildContext ctxt,
                                                          int index) {
                                                    if (index >=
                                                        TableBookingModel
                                                            .acceptedOrders
                                                            .length) {
                                                      return SizedBox();
                                                    }

                                                    return GestureDetector(
                                                      // onTap: () {
                                                      //   Navigator.push(
                                                      //       context,
                                                      //       MaterialPageRoute(
                                                      //           builder: (context) =>
                                                      //               OrderDetails(TableBookingModel
                                                      //                   .acceptedOrders[index]
                                                      //                   .orderId)));
                                                      // },
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                vertical: 2,
                                                                horizontal: 5),
                                                        child: Card(
                                                          child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        right:
                                                                            8.0),
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Icon(
                                                                        Icons
                                                                            .table_chart_outlined,
                                                                        size:
                                                                            30,
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      flex: 3,
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Static.displayOrderIdTable
                                                                              ? Text(
                                                                                  '#${TableBookingModel.acceptedOrders[index].orderId}',
                                                                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                                                                )
                                                                              : Container(),
                                                                          Text(
                                                                            '${TableBookingModel.acceptedOrders[index].customerName}',
                                                                            style: TextStyle(
                                                                                fontWeight: FontWeight.normal,
                                                                                color: Colors.black,
                                                                                fontSize: 14),
                                                                          ),
                                                                          Text(
                                                                            '${TableBookingModel.acceptedOrders[index].customerEmail}',
                                                                            style: TextStyle(
                                                                                fontWeight: FontWeight.normal,
                                                                                color: Colors.black,
                                                                                fontSize: 12),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      flex: 2,
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.end,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.end,
                                                                        children: [
                                                                          FittedBox(
                                                                            child:
                                                                                Text(
                                                                              'Date: ${TableBookingModel.acceptedOrders[index].orderDate}',
                                                                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding:
                                                                                const EdgeInsets.only(bottom: 4),
                                                                            child:
                                                                                Card(
                                                                              color: Colors.black,
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(4.0),
                                                                                child: Text(
                                                                                  'Time-${TableBookingModel.acceptedOrders[index].orderTime}',
                                                                                  style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding:
                                                                                const EdgeInsets.only(bottom: 4),
                                                                            child:
                                                                                Card(
                                                                              color: Colors.black,
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(4.0),
                                                                                child: FittedBox(
                                                                                  child: Text(
                                                                                    'Number of guests-${TableBookingModel.acceptedOrders[index].numberOfGuest}',
                                                                                    style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }),
                                          TableBookingModel
                                                      .cancelledOrders.length ==
                                                  0
                                              ? isLoading
                                                  ? Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                          CircularProgressIndicator()
                                                        ])
                                                  : Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [

                                                        // Container(
                                                        //   height: MediaQuery.of(context).size.width/1.2,
                                                        //   width: MediaQuery.of(context).size.height/2,
                                                        //   child: Padding(
                                                        //     padding: const EdgeInsets.all(8.0),
                                                        //     child: Image.asset('assets/Reserved.png'),
                                                        //   ),
                                                        // ),
                                                        Icon(
                                                          Icons.calendar_today_outlined,
                                                          size: 120,
                                                          color:
                                                              Colors.grey[300],
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          'No table booking found!',
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color:
                                                                  Colors.grey),
                                                        ),
                                                      ],
                                                    )
                                              : ListView.builder(
                                                  itemCount: TableBookingModel
                                                      .cancelledOrders.length,
                                                  itemBuilder:
                                                      (BuildContext ctxt,
                                                          int index) {
                                                    if (index >=
                                                        TableBookingModel
                                                            .cancelledOrders
                                                            .length) {
                                                      return SizedBox();
                                                    }
                                                    return GestureDetector(
                                                      onTap: () {
                                                        // Navigator.push(
                                                        //     context,
                                                        //     MaterialPageRoute(
                                                        //         builder: (context) =>
                                                        //             OrderDetails(TableBookingModel
                                                        //                 .acceptedOrders[index]
                                                        //                 .orderId)));
                                                      },
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .symmetric(
                                                                    vertical: 2,
                                                                    horizontal:
                                                                        5),
                                                            child: Card(
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        right:
                                                                            8.0),
                                                                    child: Row(
                                                                      children: [
                                                                        Expanded(
                                                                          child:
                                                                              Icon(
                                                                            Icons.table_chart_outlined,
                                                                            size:
                                                                                30,
                                                                            color:
                                                                                Colors.black,
                                                                          ),
                                                                        ),
                                                                        Expanded(
                                                                          flex:
                                                                              3,
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            children: [
                                                                              Static.displayOrderIdTable
                                                                                  ? Text(
                                                                                      '#${TableBookingModel.cancelledOrders[index].orderId}',
                                                                                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                                                                    )
                                                                                  : Container(),
                                                                              Text(
                                                                                '${TableBookingModel.cancelledOrders[index].customerName}',
                                                                                style: TextStyle(fontWeight: FontWeight.normal, color: Colors.black, fontSize: 14),
                                                                              ),
                                                                              Text(
                                                                                '${TableBookingModel.cancelledOrders[index].customerEmail}',
                                                                                style: TextStyle(fontWeight: FontWeight.normal, color: Colors.black, fontSize: 12),
                                                                              )
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Expanded(
                                                                          flex:
                                                                              2,
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.end,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.end,
                                                                            children: [
                                                                              FittedBox(
                                                                                child: Text(
                                                                                  'Date: ${TableBookingModel.cancelledOrders[index].orderDate}',
                                                                                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14),
                                                                                ),
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.only(bottom: 4),
                                                                                child: Card(
                                                                                  color: Colors.black,
                                                                                  child: Padding(
                                                                                    padding: const EdgeInsets.all(4.0),
                                                                                    child: Text(
                                                                                      'Time-${TableBookingModel.cancelledOrders[index].orderTime}',
                                                                                      style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.only(bottom: 4),
                                                                                child: Card(
                                                                                  color: Colors.black,
                                                                                  child: Padding(
                                                                                    padding: const EdgeInsets.all(4.0),
                                                                                    child: FittedBox(
                                                                                      child: Text(
                                                                                        'Number of guests-${TableBookingModel.cancelledOrders[index].numberOfGuest}',
                                                                                        style: TextStyle(color: Colors.white, fontSize: 12),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  }),
                                        ]))
                                  ])),
                        ],
                      ),
              )
            : Scaffold(
                body: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline,size: 150,color: Colors.red,),
                    Center(child: Text('Your table Booking is off!')),
                  ],
                ),
              )));
  }


  Future<void> _showMyDialog(
    TableBooking tableBooking,
  ) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('pending table booking!'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: RaisedButton(
                        onPressed: () async {
                          Navigator.pop(context);

                          setState(() {
                            isLoadingForTB = true;
                          });

                          print(
                              'tableBooking.orderId.toString()-----------------------${tableBooking.orderId.toString()}');

                          TableBookingDetailsModel.getTableBookingDetails(
                                  tableBooking.orderId.toString())
                              .then((value) => printTable());

                          TableBookingModel.tableBookingChangeStatus(
                                  tableBooking.orderId.toString(), '2')
                              .then((value) => responseIntent(value));

                          // tableBookingReceipt.tableReceipt();
                        },
                        child: Text(
                          'Accept',
                          style: TextStyle(color: Colors.white),
                        ),
                        color: Colors.green,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: RaisedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          setState(() {
                            isLoadingForTB = true;
                          });

                          TableBookingModel.tableBookingChangeStatus(
                                  tableBooking.orderId.toString(), '3')
                              .then((value) => responseIntentCancel(value));
                        },
                        child: Text('Cancel',
                            style: TextStyle(color: Colors.white)),
                        color: Colors.red,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          // actions: <Widget>[
          //   TextButton(
          //     child: Text(
          //       'ok',
          //       style: TextStyle(fontSize: 16),
          //     ),
          //     onPressed: () {
          //       Navigator.of(context).pop();
          //     },
          //   ),
          // ],
        );
      },
    );
  }

  responseIntent(value) async {
    await TableBookingModel.getAllTableBooking(1);
    setState(() {
      tableBookingReceipt.tableReceipt();
      isLoadingForTB = false;
    });
    print(
        'response accept_Table booking------------------------------------$value');
    if (value != 'failed') {
      ('response accept_Table booking------------------------------------failed');
      // Navigator.pop(context);
    }
  }

  responseIntentCancel(value) async {
    await TableBookingModel.getAllTableBooking(1);
    setState(() {
      isLoadingForTB = false;
    });
    print(
        'response accept_Table booking------------------------------------$value');
    if (value != 'failed') {
      // Navigator.pop(context);
    }
  }

  Container _buildDivider() {
    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 8.0,
      ),
      width: double.infinity,
      height: 1.0,
      color: Colors.grey.shade300,
    );
  }

  printTable() {
    print(
        'TableBookingDetailsModel.customer. ------------------${TableBookingDetailsModel.customer.orderId}');
    print(
        'TableBookingDetailsModel.customer. ------------------${TableBookingDetailsModel.customer.customerName}');
    print(
        'TableBookingDetailsModel.customer. ------------------${TableBookingDetailsModel.customer.orderTime}');
  }

  Future _refreshData() async {
    await TableBookingModel.getAllTableBooking(1);
    setState(() {});
  }
}
