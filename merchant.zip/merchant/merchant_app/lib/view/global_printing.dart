import 'package:blue/global/constant.dart';
import 'package:blue/printer/front_receipt.dart';
import 'package:blue/printer/kitchen_receipt.dart';

 class GlobalPrinting {



  printOrder(int id){
    FrontReceipt frontReceipt=FrontReceipt();

    print('---------autoPrintOrder----------${Static.autoPrintOrder}');
    print('---------Static.Number_of_front_receipt_Value----------${Static.Number_of_front_receipt_Value}');
    print('---------Static.kitchenReceiptDefault----------${Static.kitchenReceiptDefault}');
    print('---------Static.kitchenReceiptSameAsFront----------${Static.kitchenReceiptSameAsFront}');
    // if(Static.autoPrintOrder){
      if (Static.Number_of_front_receipt_Value == 'One') {
        frontReceipt.frontReceipt();
        if(Static.kitchenReceiptDefault){
          printKitchenReceipt(id);
        }
        if(Static.kitchenReceiptSameAsFront){
          frontReceipt.frontReceipt();
        }

      } else if (Static.Number_of_front_receipt_Value == 'Two') {
        for (int i = 0; i < 2; i++) {
          frontReceipt.frontReceipt();
          if (i == 1) {
            if(Static.kitchenReceiptDefault){
              printKitchenReceipt(id);
            }
            if(Static.kitchenReceiptSameAsFront){
              frontReceipt.frontReceipt();
            }
          }
        }
      } else if (Static.Number_of_front_receipt_Value == 'Three') {
        for (int i = 0; i < 3; i++) {
          frontReceipt.frontReceipt();
          if (i == 2) {
            if(Static.kitchenReceiptDefault){
              printKitchenReceipt(id);
            }
            if(Static.kitchenReceiptSameAsFront){
              frontReceipt.frontReceipt();
            }
          }
        }
      } else if (Static.Number_of_front_receipt_Value == 'Four') {
        for (int i = 0; i < 4; i++) {
          frontReceipt.frontReceipt();
          if (i == 3) {
            if(Static.kitchenReceiptDefault){
              printKitchenReceipt(id);
            }
            if(Static.kitchenReceiptSameAsFront){
              frontReceipt.frontReceipt();
            }
          }
        }
      } else if (Static.Number_of_front_receipt_Value == 'Five') {
        for (int i = 0; i < 5; i++) {
          frontReceipt.frontReceipt();
          if (i == 4) {
            if(Static.kitchenReceiptDefault){
              printKitchenReceipt(id);
            }
            if(Static.kitchenReceiptSameAsFront){
              frontReceipt.frontReceipt();
            }
          }
        }
      }
    // }



  }
  printKitchenReceipt(int id) {
    KitchenReceipt kitchenReceipt= KitchenReceipt();
    if (Static.Number_of_kitchen_receipt_Value == 'One') {
      kitchenReceipt.kitchenReceipt(id);
    } else if (Static.Number_of_kitchen_receipt_Value == 'Two') {
      for (int i = 0; i < 2; i++) {
        kitchenReceipt.kitchenReceipt(id);
      }
    } else if (Static.Number_of_kitchen_receipt_Value == 'Three') {
      for (int i = 0; i < 3; i++) {
        kitchenReceipt.kitchenReceipt(id);
      }
    } else if (Static.Number_of_kitchen_receipt_Value == 'Four') {
      for (int i = 0; i < 4; i++) {
        kitchenReceipt.kitchenReceipt(id);
      }
    } else if (Static.Number_of_kitchen_receipt_Value == 'Five') {
      for (int i = 0; i < 5; i++) {
        kitchenReceipt.kitchenReceipt(id);
      }
    }
  }

}
