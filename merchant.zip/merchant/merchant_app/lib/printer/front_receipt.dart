import 'dart:ffi';
import 'dart:typed_data';

import 'package:blue/global/constant.dart';
import 'package:blue/model/home_model.dart';
import 'package:blue/model/order_details_model.dart';
import 'package:blue/podo/food_item.dart';
import 'package:blue/printer/static_receipt.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';

import 'items_pojo.dart';

class FrontReceipt {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  static const int TOTAL_CHARACTER = 32;

  static const num SPACE_BEFORE_PRICE = 18;

  static const int NORMAL_SIZE_TEXT = 0;
  static const int BOLD_SIZE_TEXT = 1;
  static const int MEDIUM_BOLD_SIZE_TEXT = 2;
  static const int LARGE_BOLD_SIZE_TEXT = 3;
  static const int EXTRA_LARGE_BOLD_SIZE_TEXT = 3;

  static const int ESC_ALIGN_LEFT = 0;
  static const int ESC_ALIGN_CENTER = 1;
  static const int ESC_ALIGN_RIGHT = 2;
  frontReceipt() async {
    //SIZE
    // 0- normal size text
    // 1- only bold text
    // 2- bold with medium text
    // 3- bold with large text
    //ALIGN
    // 0- ESC_ALIGN_LEFT
    // 1- ESC_ALIGN_CENTER
    // 2- ESC_ALIGN_RIGHT

//     var response = await http.get("IMAGE_URL");
//     Uint8List bytes = response.bodyBytes;
    bluetooth.isConnected.then((isConnected) {

      if (isConnected) {

    if(Static.kitchenReceiptSameAsFront){
      bluetooth.printCustom(
          '        Kitchen Receipt        ', EXTRA_LARGE_BOLD_SIZE_TEXT, 1);

      bluetooth.printCustom(
          '       ------------------       ', BOLD_SIZE_TEXT, 1);
      bluetooth.printNewLine();
    }

        bluetooth.printCustom(
            HomeModel.businessName, EXTRA_LARGE_BOLD_SIZE_TEXT, 1);
        bluetooth.printNewLine();

        if(!Static.hideRestaurantAddressOnReceipt){
          bluetooth.printCustom(HomeModel.businessAddress, BOLD_SIZE_TEXT, 1);
        }
        bluetooth.printCustom(HomeModel.businessPostCode, BOLD_SIZE_TEXT, 1);
        bluetooth.printCustom(
            'Tel:' + HomeModel.businessContact, BOLD_SIZE_TEXT, 1);
        bluetooth.printCustom(StaticReceipt.WEB_DELIVERY, BOLD_SIZE_TEXT, 1);
        bluetooth.printNewLine();

        bluetooth.printCustom(
            OrderDetailsModel.customer.customerName, BOLD_SIZE_TEXT, 0);
        bluetooth.printCustom(
            OrderDetailsModel.customer.customerContact, BOLD_SIZE_TEXT, 0);
        bluetooth.printCustom(
            OrderDetailsModel.customer.deliveryAddress, BOLD_SIZE_TEXT, 0);
        bluetooth.printCustom(
            OrderDetailsModel.customer.postCode, BOLD_SIZE_TEXT, 0);
        bluetooth.printNewLine();

        bluetooth.printLeftRight("Item", "Price (GBP)", 1);
        bluetooth.printLeftRight("----", "-----------", 1);

        for (FoodItem foodItem in OrderDetailsModel.foodItems) {
          String breakT = breakText('${foodItem.quantity}X', foodItem.itemName,
              (foodItem.itemPrice).toString());
          bluetooth.printCustom(breakT, BOLD_SIZE_TEXT, 0);
          bluetooth.printCustom(
              '--------------------------------', BOLD_SIZE_TEXT, 1);
        }

        bluetooth.printNewLine();
        bluetooth.printNewLine();
        bluetooth.printLeftRight("Total",
            (OrderDetailsModel.customer.total).toString(), BOLD_SIZE_TEXT);

        bluetooth.printLeftRight(
            "Delivery Charge",
            (OrderDetailsModel.customer.deliveryCharge).toString(),
            BOLD_SIZE_TEXT);
        bluetooth.printLeftRight(
            "Service Charge",
            (OrderDetailsModel.customer.serviceCharge).toString(),
            BOLD_SIZE_TEXT);
        bluetooth.printCustom(
            '--------------------------------', BOLD_SIZE_TEXT, 1);
        bluetooth.printLeftRight(
            "Total to pay",
            (OrderDetailsModel.customer.totalToPay).toString() + ' GBP',
            BOLD_SIZE_TEXT);
        bluetooth.printNewLine();

        bluetooth.printCustom("Order placed at", BOLD_SIZE_TEXT, 0);
        bluetooth.printCustom((OrderDetailsModel.customer.orderDate).toString(),
            BOLD_SIZE_TEXT, 0);
        // bluetooth.printCustom((OrderDetailsModel.customer.).toString(), 0, 0);
        bluetooth.printCustom(
            "Payment method: " + OrderDetailsModel.customer.paymentMethod,
            BOLD_SIZE_TEXT,
            0);
        bluetooth.printCustom(
            "Payment status: " + OrderDetailsModel.customer.paymentStatus,
            BOLD_SIZE_TEXT,
            0);

        bluetooth.printNewLine();
        bluetooth.printCustom("Thank You", 2, 1);
        // bluetooth.printNewLine();
        bluetooth.printQRcode(StaticReceipt.BUSINESS_QRCODE, 200, 200, 1);
        // bluetooth.printNewLine();
        bluetooth.paperCut();
        bluetooth.printNewLine();

//
//
//
//         bluetooth.printNewLine();
//         bluetooth.printCustom(StaticReceipt.BUSINESS_HEADER,3,1);
//         bluetooth.printNewLine();
//         bluetooth.printImage(pathImage);   //path of your image/logo
//         bluetooth.printNewLine();
// //      bluetooth.printImageBytes(bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes));
//         bluetooth.printLeftRight("LEFT", "RIGHT",0);
//         bluetooth.printLeftRight("LEFT", "RIGHT",1);
//         bluetooth.printNewLine();
//         bluetooth.printLeftRight("LEFT", "RIGHT",2);
//         bluetooth.printLeftRight("LEFT", "RIGHT",3);
//         bluetooth.printNewLine();
//         bluetooth.printLeftRight("LEFT", "RIGHT",4);
//         String testString = " Hello world";
//         bluetooth.printCustom(testString, 1, 1, charset: "windows-1250");
//         bluetooth.printNewLine();
//         bluetooth.printLeftRight("Številka:", "18000001", 1, charset: "windows-1250");
//         bluetooth.printCustom("Body left",1,0);
//         bluetooth.printCustom("Body right",0,2);
//         bluetooth.printNewLine();
//         bluetooth.printCustom("Thank You",2,1);
//         bluetooth.printNewLine();
//         bluetooth.printQRcode("PO1 5HD", 200, 200, 1);
//         bluetooth.printNewLine();
//         bluetooth.printNewLine();
//         bluetooth.paperCut();
//         bluetooth.printNewLine();
      }
    });
  }

  static String breakText(String piece, String text, String price) {
    String formattedText = "$piece";
    String tempText = "";
    List<String> parts = text.split(" ");
    int breakCount = 0;
    for (int i = 0; i < parts.length; i++) {
      if ((tempText.length + parts[i].length) > 20) {
        breakCount++;
        if (breakCount == 1) {
          formattedText +=
              '${writeSpace(TOTAL_CHARACTER - (formattedText.length + price.length))}$price';
          breakCount = 2;
        }
        formattedText += "\n";
        tempText = "";
      } else {
        formattedText += (parts[i] + " ");
        tempText += parts[i] + " ";
      }
    }
    if (breakCount == 0) {
      formattedText +=
          '${writeSpace(TOTAL_CHARACTER - (formattedText.length + price.length))}$price';
    }

    print(
        'formattedText length-------------------------------${formattedText.length}');

    return formattedText;
  }

  static String writeSpace(int length) {
    print('length---------------------------------------$length');
    String space = "";
    for (int i = 0; i < length; i++) {
      space += " ";
    }
    return space;
  }
}
