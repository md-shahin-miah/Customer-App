class Items{
  String itemName;
  String price;

  Items(this.itemName, this.price);
}