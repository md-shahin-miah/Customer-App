class StaticReceipt{


 static  String BUSINESS_HEADER='OrderE';

 static  String ADDRESS='210 Fratton Road, Portsmouth';
 static String POSTCODE='PO1 5HD';
 static  String CELL='008 8997 7665';
 static  String WEB_DELIVERY='';


 static  String USER_NAME='Dummy Name';
 static  String USER_MOBILE='223 8800 2233';
 static  String USER_ADDRESS='120 Fratton Road, Portsmouth';
 static  String USER_POSTCODE='PO4 3HD';

 static  String TOTAL_AMOUNT='100.00';
 static  String DELIVEERY_CHARGE='0.00';
 static  String SERVICE_CHARGE='2.50';
 static  String TOTAL_TO_PAY='102.50';


 static  String ORDER_PLACED_AT='3/24/2021 7.22 PM';
 static  String WANTED_ASAP='Wanted Asap';
 static  String PAYMENT_METHOD='Online';
 static  String PAYMENT_STATUS='Paid';


 static  String BUSINESS_QRCODE='PO1 5HD';










}